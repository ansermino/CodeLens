def some_other(string1, string2):
	mod1 = ''.split(list(string1).reverse())
	mod2 = ''.split(list(string2).reverse())
	return mod2 + mod1
