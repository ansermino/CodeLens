def mySquare(x):
    square = x ** 2
    my = x + 5
    for k in range(1, 10):
        print(k)

    if my > 5:
        print("Hey")

    return square


def squareTwoNums(x, y, user):
    mySquare(x)
    mySquare(y)
    print("Hello, {} !".format(user))

