def mySquare(x):
    square = x * x
    if square > x * 2:
        print("x is greater than 2!")

    return square


def sayHello(name):
    print("Hello, " + name + "!")
    print("Have a nice day!")


def squareTwoNums(x, y, user):
    sayHello(user)
    res1 = mySquare(x)
    res2 = mySquare(y)
    res3 = mySquare(x + y)
    print("{} is greater than {}, if x and y are greater than 1".format(res3, res1 + res2))

