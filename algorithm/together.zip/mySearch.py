def depthFirstSearch(problem):
    """
    Search the deepest nodes in the search tree first.

    Your search algorithm needs to return a list of actions that reaches the
    goal. Make sure to implement a graph search algorithm.

    To get started, you might want to try some of these simple commands to
    understand the search problem that is being passed in:

    print "Start:", problem.getStartState()
    print "Is the start a goal?", problem.isGoalState(problem.getStartState())
    print "Start's successors:", problem.getSuccessors(problem.getStartState())
    """
    from util import Stack

    openFront = Stack()
    # for (orig, next_pos, cost) in problem.getSuccessors(problem.getStartState()):
    #     orig_path = [(orig, next_pos, cost)]
    #     print orig_path
    #     openFront.push(orig_path)
    openFront.push([(problem.getStartState(), None, 0)])
    print(problem.getStartState())
    while not openFront.isEmpty():
        move = openFront.pop()
        state = move[-1]
        if problem.isGoalState(state[0]):
            path = []
            for node in move:
                if node[1] is not None:
                    path.append(node[1])
            print(path)
            return path

        for (succ, next_pos, _) in problem.getSuccessors(state[0]):
            visited = False
            for node in move:
                if node[0] == succ:
                    visited = True
            if not visited:
                new_path = list(move)
                new_path.append((succ, next_pos))
                openFront.push(new_path)

    print("No path could be found")



# def breadthFirstSearch(problem):
#     """Search the shallowest nodes in the search tree first."""
#     from util import Queue
#     seen = {}
#     openFront = Queue()
#     seen[problem.getStartState()] = 0
#     # for (orig, next_pos, cost) in problem.getSuccessors(problem.getStartState()):
#     #     seen[orig] = cost
#     #     orig_path = [(orig, next_pos, cost)]
#     #     openFront.push(orig_path)
#     openFront.push([(problem.getStartState(), None, 0)])
#
#     while not openFront.isEmpty():
#         move = openFront.pop()
#         state = move[-1]
#         if problem.isGoalState(state[0]):
#             path = []
#             for node in move:
#                 if node[1] is not None:
#                     path.append(node[1])
#             return path
#
#         for (succ, next_pos, cost) in problem.getSuccessors(state[0]):
#             if (not (succ in seen)) or (state[2] + cost < seen[succ]):
#                 seen[succ] = state[2] + cost
#                 new_path = list(move)
#                 new_path.append((succ, next_pos, state[2] + cost))
#                 openFront.push(new_path)
#
#
#     print "No path could be found"
#
#
# def uniformCostSearch(problem):
#     """Search the node of least total cost first."""
#     "*** YOUR CODE HERE ***"
#
#     from util import PriorityQueue
#
#     seen = {}
#     seen[problem.getStartState()] = 0
#     openFront = PriorityQueue()
#     # for (orig, next_pos, cost) in problem.getSuccessors(problem.getStartState()):
#     #     seen[orig] = cost
#     #     orig_path = [(orig, next_pos, cost)]
#     #     openFront.push(orig_path, cost)
#     openFront.push([(problem.getStartState(), None, 0)], 0)
#
#     while not openFront.isEmpty():
#         move = openFront.pop()
#         state = move[-1]
#         if problem.isGoalState(state[0]):
#             path = []
#             for node in move:
#                 if node[1] is not None:
#                     path.append(node[1])
#             return path
#
#         for (succ, next_pos, cost) in problem.getSuccessors(state[0]):
#             if (not (succ in seen)) or (state[2] + cost < seen[succ]):
#                 seen[succ] = state[2] + cost
#                 new_path = list(move)
#                 new_path.append((succ, next_pos, state[2] + cost))
#                 openFront.push(new_path, state[2] + cost)
#
#     print "No path could be found"
#
#
# def nullHeuristic(state, problem=None):
#     """
#     A heuristic function estimates the cost from the current state to the nearest
#     goal in the provided SearchProblem.  This heuristic is trivial.
#     """
#     return 0
#
# # TODO: Figure out why it costs 55
# def aStarSearch(problem, heuristic=nullHeuristic):
#     """Search the node that has the lowest combined cost and heuristic first."""
#     "*** YOUR CODE HERE ***"
#     from util import PriorityQueue
#
#     seen = {}
#     seen[problem.getStartState()] = 0
#     openFront = PriorityQueue()
#
#     for (orig, next_pos, cost) in problem.getSuccessors(problem.getStartState()):
#         seen[orig] = cost
#         orig_path = [(orig, next_pos, cost)]
#         openFront.push(orig_path, cost + heuristic(orig, problem))
#
#     while not openFront.isEmpty():
#         move = openFront.pop()
#         state = move[-1]
#         if problem.isGoalState(state[0]):
#             path = []
#             for node in move:
#                 path.append(node[1])
#             print path
#             return path
#
#         for (succ, next_pos, cost) in problem.getSuccessors(state[0]):
#             if (not (succ in seen)) or (state[2] + cost < seen[succ]):
#                 seen[succ] = state[2] + cost
#                 new_path = list(move)
#                 new_path.append((succ, next_pos, state[2] + cost))
#                 openFront.push(new_path, state[2] + cost + heuristic(succ, problem))
#
#     print "No path could be found"
#
#
# # Abbreviations
# bfs = breadthFirstSearch
# dfs = depthFirstSearch
# astar = aStarSearch
# ucs = uniformCostSearch
#
#
