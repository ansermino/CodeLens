

#####################################################
# This portion is incomplete.  Time to write code!  #
#####################################################

class CornersProblem(search.SearchProblem):

    def getSuccessors(self, state):
        """
        Returns successor states, the actions they require, and a cost of 1.

         As noted in search.py:
            For a given state, this should return a list of triples, (successor,
            action, stepCost), where 'successor' is a successor to the current
            state, 'action' is the action required to get there, and 'stepCost'
            is the incremental cost of expanding to that successor
        """

        successors = []
        for action in [Directions.NORTH, Directions.SOUTH, Directions.EAST, Directions.WEST]:
            # Add a successor state to the successor list if the action is legal
            # Here's a code snippet for figuring out whether a new position hits a wall:
            x,y = state[0]
            dx, dy = Actions.directionToVector(action)
            nextx, nexty = int(x + dx), int(y + dy)
            hitsWall = self.walls[nextx][nexty]
            visited = state[1]
            if not hitsWall:
                if (nextx, nexty) == self.corners[0]:
                    visited |= (1 << 0)
                    #visited *= 3
                elif (nextx, nexty) == self.corners[1]:
                    visited |= (1 << 1)
                    #visited *= 5

                elif (nextx, nexty) == self.corners[2]:
                    visited |= (1 << 2)
                    #visited *= 7

                elif (nextx, nexty) == self.corners[3]:
                    visited |= (1 << 3)
                    #visited *= 11

                nextState = (nextx, nexty)
                successors.append(((nextState, visited), action, 1))

        self._expanded += 1 # DO NOT CHANGE

        return successors

def cornersHeuristic(state, problem):
    from util import manhattanDistance
    corners = problem.corners # These are the corner coordinates
    walls = problem.walls # These are the walls of the maze, as a Grid (game.py)
    position = state[0]
    visited = []

    if state[1] & 0b0001 or position == corners[0]:
        visited.append(corners[0])
    if state[1] & 0b0010 or position == corners[1]:
        visited.append(corners[1])
    if state[1] & 0b0100 or position == corners[2]:
        visited.append(corners[2])
    if state[1] & 0b1000 or position == corners[3]:
        visited.append(corners[3])

    if len(visited) == 4:
        return 0
    if len(visited) == 3:
        not_visited = [x for x in corners if x not in visited]
        return manhattanDistance(position, not_visited[0])

    not_visited = [x for x in corners if x not in visited]
    heu = [sys.maxint for _ in range(len(not_visited)-1)]

    for i in range(len(not_visited)-1):
        for node in not_visited:
            if not (node == not_visited[i]):
                if euclidianDistance(not_visited[i], node) < heu[i]:
                    heu[i] = euclidianDistance(not_visited[i], node)
    heur = sum(heu)
    dist = sys.maxint

    for node in not_visited:
            if euclidianDistance(position, node) < dist:
                dist = euclidianDistance(position, node)
    return heur + dist


def foodHeuristic(state, problem):

    from util import manhattanDistance

    position, foodGrid = state
    if foodGrid.count() == 0:
        return 0

    grid = foodGrid.asList()

    heuristic = -1
    # for food in grid:
    #     if heuristic == -1 or manhattanDistance(position, food) < heuristic:
    #         heuristic = mazeDistance(position, food, problem.startingGameState)
    #
    # if len(grid) > 1:
    #     heuristic += mazeDistance(grid[0], grid[-1], problem.startingGameState)
    for food in grid:
        if heuristic == -1 or manhattanDistance(position, food) < heuristic:
            heuristic = manhattanDistance(position, food)

    if len(grid) > 1:
        heuristic += manhattanDistance(grid[0], grid[-1])

    return heuristic

