
def depthFirstSearch(problem):
    """
    Search the deepest nodes in the search tree first.

    Your search algorithm needs to return a list of actions that reaches the
    goal. Make sure to implement a graph search algorithm.

    To get started, you might want to try some of these simple commands to
    understand the search problem that is being passed in:

    print "Start:", problem.getStartState()
    print "Is the start a goal?", problem.isGoalState(problem.getStartState())
    print "Start's successors:", problem.getSuccessors(problem.getStartState())
    """
    "*** YOUR CODE HERE ***"
    start = problem.getStartState()
    open = util.Stack()
    open.push(start)
    while not open.isEmpty():
        n = open.pop()
        if type(n) is list:
            state = n[-1][0]
        else:
            state = n
            n = [n]
        if problem.isGoalState(state):
            ideal_action = []
            n = n[1:]
            for moves in n:
                ideal_action.append(moves[1])
            return ideal_action

        for succ in problem.getSuccessors(state):
            new_node=n[:]
            if not any(succ[0] == states[0] for states in new_node):
                new_node.append(succ)
                open.push(new_node)
    return False
#
# def breadthFirstSearch(problem):
#     """Search the shallowest nodes in the search tree first."""
#     "*** YOUR CODE HERE ***"
#     start = problem.getStartState()
#     open = util.Queue()
#     open.push(start)
#     seen = dict()
#     seen[start] = 0
#     while not open.isEmpty():
#         n = open.pop()
#         if type(n) is list:
#             state = n[-1][0]
#             cost = len(n)
#         else:
#             state = n
#             n = [n]
#             cost = 0
#         if cost <= seen[state]:
#             if problem.isGoalState(state):
#                 ideal_action = []
#                 n=n[1:]
#                 for moves in n:
#                     ideal_action.append(moves[1])
#                 return ideal_action
#             for succ in problem.getSuccessors(state):
#                 new_node = n[:]
#                 cost1 = len(new_node)+1
#                 result = succ[0] in seen
#                 if (not result) or (cost1 < seen[succ[0]]):
#                     new_node.append(succ)
#                     open.push(new_node)
#                     seen[succ[0]] = cost1
#     return False
#
#
# def uniformCostSearch(problem):
#     """Search the node of least total cost first."""
#     "*** YOUR CODE HERE ***"
#     start = problem.getStartState()
#     open = util.PriorityQueue()
#     open.push(start, 0)
#     seen = dict()
#     seen[start] = 0
#     while not open.isEmpty():
#         n = open.pop()
#         if type(n) is list:
#             state = n[-1][0]
#             cost = 0
#             n_copy = n[1:]
#             for i in n_copy:
#                 cost += i[2]
#         else:
#             state = n
#             n = [n]
#             cost = 0
#         if cost <= seen[state]:
#             if problem.isGoalState(state):
#                 ideal_action = []
#                 n = n[1:]
#                 for moves in n:
#                     ideal_action.append(moves[1])
#                 return ideal_action
#             for succ in problem.getSuccessors(state):
#                 new_node = n[:]
#                 cost1 = 0
#                 if len(n) != 1:
#                     n_copy2 = n[1:]
#                     for i in n_copy2:
#                         cost1 += i[2]
#                 cost1 += succ[2]
#                 result = succ[0] in seen
#                 if (not result) or (cost1 < seen[succ[0]]):
#                     new_node.append(succ)
#                     open.push(new_node, cost1)
#                     seen[succ[0]] = cost1
#     return False
#
# def nullHeuristic(state, problem=None):
#     """
#     A heuristic function estimates the cost from the current state to the nearest
#     goal in the provided SearchProblem.  This heuristic is trivial.
#     """
#     return 0
#
# def aStarSearch(problem, heuristic=nullHeuristic):
#     """Search the node that has the lowest combined cost and heuristic first."""
#     "*** YOUR CODE HERE ***"
#     start = problem.getStartState()
#     open = util.PriorityQueue()
#     open.push(start, 0)
#     seen = dict()
#     seen[start] = 0
#     while not open.isEmpty():
#         n = open.pop()
#         if type(n) is list:
#             state = n[-1][0]
#             cost = 0
#             n_copy = n[1:]
#             for i in n_copy:
#                 cost += i[2]
#             cost += heuristic(n[-1][0], problem)
#         else:
#             state = n
#             n = [n]
#             cost = 0
#         if cost <= seen[state]:
#             if problem.isGoalState(state):
#                 ideal_action = []
#                 n = n[1:]
#                 for i in n:
#                     ideal_action.append(i[1])
#                 return ideal_action
#             for succ in problem.getSuccessors(state):
#                 new_node = n[:]
#                 cost1 = 0
#                 n_copy2 = n[1:]
#                 for i in n_copy2:
#                     cost1 += i[2]
#                 cost1 += (succ[2]+heuristic(succ[0], problem))
#                 result = succ[0] in seen
#                 if (not result) or (cost1 < seen[succ[0]]):
#                     new_node.append(succ)
#                     open.push(new_node, cost1)
#                     seen[succ[0]] = cost1
#     return False
#
#
# # Abbreviations
# bfs = breadthFirstSearch
# dfs = depthFirstSearch
# astar = aStarSearch
# ucs = uniformCostSearch
#
# #Helper Methods
#
#
