

#####################################################
# This portion is incomplete.  Time to write code!  #
#####################################################

class CornersProblem(search.SearchProblem):
    def getSuccessors(self, state):
        """
        Returns successor states, the actions they require, and a cost of 1.

         As noted in search.py:
            For a given state, this should return a list of triples, (successor,
            action, stepCost), where 'successor' is a successor to the current
            state, 'action' is the action required to get there, and 'stepCost'
            is the incremental cost of expanding to that successor
        """

        successors = []
        for action in [Directions.NORTH, Directions.SOUTH, Directions.EAST, Directions.WEST]:
            # Add a successor state to the successor list if the action is legal
            # Here's a code snippet for figuring out whether a new position hits a wall:
            #   x,y = currentPosition
            #   dx, dy = Actions.directionToVector(action)
            #   nextx, nexty = int(x + dx), int(y + dy)
            #   hitsWall = self.walls[nextx][nexty]
            "*** YOUR CODE HERE ***"
            x,y = state[0]
            dx, dy = Actions.directionToVector(action)
            nextx, nexty = int(x + dx), int(y + dy)
            if not self.walls[nextx][nexty]:
                corners_visited = state[1]
                if (nextx,nexty) in self.corners:
                    if not (nextx, nexty) in corners_visited:
                        copy_tuple = []
                        for i in corners_visited:
                            copy_tuple.append(i)
                        copy_tuple.append((nextx,nexty))
                        corners_visited = tuple(copy_tuple)
                nextState = ((nextx, nexty),corners_visited)
                successors.append( (nextState, action, 1))

        self._expanded += 1 # DO NOT CHANGE
        return successors

def cornersHeuristic(state, problem):
    "*** YOUR CODE HERE ***"
    closest_corner = None
    distance = None
    second_distance = None

    for i in corners:
        if i not in state[1]:
            abs_distance = abs(state[0][0] - i[0]) + abs(state[0][1] - i[1])
            if distance is None or abs_distance < distance :
                distance = abs_distance
                closest_corner = i
    for i in corners:
        if i not in state[1] and i != closest_corner:
            abs_distance = abs(closest_corner[0] - i[0]) + abs(closest_corner[1] - i[1])
            if second_distance is None or abs_distance < second_distance:
                second_distance = abs_distance
    if distance is not None and second_distance is not None:
        return distance+second_distance
    elif distance is not None and  second_distance is None:
        return distance
    return 0 # Default to trivial solution

def foodHeuristic(state, problem):

    position, foodGrid = state
    if len(foodGrid.asList()) == 0:
        return 0
    elif len(foodGrid.asList()) == 1:
        return abs(position[0]-foodGrid.asList()[0][0])+abs(position[1]-foodGrid.asList()[0][1])
        # euclideanHeuristic(state, foodGrid.asList()[0])
    else:
        "*** YOUR CODE HERE ***"
        max_distance = 0;
        food_1 = None
        food_2 = None
        for i in foodGrid.asList():
            for j in foodGrid.asList():
                abs_distance = abs(j[0] - i[0]) + abs(j[1] - i[1])
                if abs_distance > max_distance:
                    max_distance = abs_distance
                    food_1 = i
                    food_2 = j
        if food_1 is not None and food_2 is not None:
            state_to_food = min(abs(position[0] - food_1[0]) + abs(position[1] - food_1[1]), abs(position[0] - food_2[0]) + abs(position[1] - food_2[1]) )
            return state_to_food + max_distance
